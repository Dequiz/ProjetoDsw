public class testeCarro{  	public static void main (String args[]){ 
 	 	Carro carro = new Carro(); 
 	 	 
 	 	carro.encherTanque(10); 
 	 	carro.carroLigado = true; 
        System.out.println(carro.litrosNoTanque);
 	} 
} 
