public class Garrafa{  	
    private String tipo; 
 
 	public Garrafa (String tipo){
          	 	this.tipo = tipo; 
 	} 
 	 
 	public void setTipo (String tipo){  
        	 	this.tipo = tipo; 
 	} 
 	 
 	public String getTipo(){ 
 	 	return tipo; 
 	} 
} 
