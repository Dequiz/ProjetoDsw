public class testeCirculo{
      	public static void main (String args[]){  	 
            Circulo c = new Circulo();
        c.setRaio(10);
        System.out.println(c.getRaio());
 	} 
}  

