public class Carro extends Veiculo{ 
 	private String cad; 
 	 
 	public String getCad(){  	 	return cad; 
 	} 	 
} 
