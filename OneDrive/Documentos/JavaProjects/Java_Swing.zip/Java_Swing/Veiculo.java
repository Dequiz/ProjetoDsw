public final class Veiculo{ 
 	private String chassi; 
 	 
 
 
 
} 	public String getChassi(){  	return chassi; 
} 	 
