
public class TesteBanco{
  	public static void main (String args[]){  
        
		ClienteBanco c1 = new ClienteBanco("Andre", "427.946.588.67","Rua Maria Clara");
		System.out.println(c1);

} 
}