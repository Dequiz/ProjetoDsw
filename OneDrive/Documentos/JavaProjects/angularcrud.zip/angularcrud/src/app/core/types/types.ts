
export interface Pessoa {
  id?: string | number;
  nome: string;
  sobrenome: string;
  dtNascimento: string;
}
